
import React from 'react';
import { X, Calendar as CalendarIcon, Trophy, Flame } from 'lucide-react';

interface CalendarModalProps {
  isOpen: boolean;
  onClose: () => void;
  streak: number;
}

export const CalendarModal: React.FC<CalendarModalProps> = ({ isOpen, onClose, streak }) => {
  if (!isOpen) return null;

  // Generate 2 months of mock data
  const days = Array.from({ length: 60 }, (_, i) => ({
    val: Math.random() > 0.3,
    day: i + 1
  }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" onClick={onClose}></div>
      
      <div className="relative w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-300">
         <div className="p-6">
            <div className="flex justify-between items-center mb-6">
               <h2 className="text-2xl font-display font-bold text-white flex items-center gap-2">
                 <CalendarIcon className="text-neon-lime" size={24}/> Focus Log
               </h2>
               <button onClick={onClose} className="p-2 bg-zinc-900 rounded-full text-zinc-400 hover:text-white">
                 <X size={20} />
               </button>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-8">
               <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                  <div className="flex items-center gap-2 mb-1">
                     <Flame size={16} className="text-orange-500" />
                     <span className="text-zinc-500 text-xs uppercase font-bold">Current Streak</span>
                  </div>
                  <p className="text-2xl font-bold text-white">{streak} Days</p>
               </div>
               <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                  <div className="flex items-center gap-2 mb-1">
                     <Trophy size={16} className="text-yellow-500" />
                     <span className="text-zinc-500 text-xs uppercase font-bold">Total Sessions</span>
                  </div>
                  <p className="text-2xl font-bold text-white">42</p>
               </div>
            </div>

            <h3 className="text-sm font-bold text-zinc-400 mb-3">Last 60 Days</h3>
            <div className="grid grid-cols-10 gap-2">
               {days.map((d, i) => (
                 <div 
                   key={i} 
                   className={`aspect-square rounded-md flex items-center justify-center text-[8px] font-mono
                     ${d.val ? 'bg-green-500/80 text-black shadow-[0_0_5px_rgba(74,222,128,0.3)]' : 'bg-zinc-900 text-zinc-700'}`}
                 >
                   {d.val && '✓'}
                 </div>
               ))}
            </div>
            
            <div className="mt-8 pt-6 border-t border-zinc-900 text-center">
              <p className="text-zinc-600 text-xs">Consistency is the only metric that matters.</p>
            </div>
         </div>
      </div>
    </div>
  );
};
