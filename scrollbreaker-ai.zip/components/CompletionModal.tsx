
import React from 'react';
import { Button } from './Button';
import { TwitterIcon } from './BrandIcons';
import { Share2, CheckCircle2, Copy, Mail, MessageCircle } from 'lucide-react';
import { Challenge } from '../types';

interface CompletionModalProps {
  isOpen: boolean;
  onClose: () => void;
  challenge: Challenge | null;
}

export const CompletionModal: React.FC<CompletionModalProps> = ({ isOpen, onClose, challenge }) => {
  if (!isOpen || !challenge) return null;

  const shareText = `I just completed the ${challenge.title} challenge on Monk Mode OS. ${challenge.selectedOption} hours of pure focus. 🧘‍♂️⚡ #MonkMode #Focus`;
  const shareUrl = "https://monkmode.app"; // Placeholder

  const handleShare = (platform: 'twitter' | 'whatsapp' | 'email' | 'copy') => {
    switch (platform) {
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${shareUrl}`, '_blank');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`, '_blank');
        break;
      case 'email':
        window.open(`mailto:?subject=Monk Mode Challenge Complete&body=${encodeURIComponent(shareText + ' ' + shareUrl)}`);
        break;
      case 'copy':
        navigator.clipboard.writeText(shareText + ' ' + shareUrl);
        alert('Copied to clipboard!');
        break;
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" onClick={onClose}></div>
      
      <div className="relative w-full max-w-sm bg-gradient-to-b from-zinc-900 to-black border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-500">
        
        {/* Confetti / Glow Effect */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -mt-20 w-64 h-64 bg-neon-lime/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="p-8 text-center relative z-10">
          
          <div className="w-24 h-24 bg-neon-lime/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-neon-lime/30 animate-pulse-fast">
            <CheckCircle2 size={48} className="text-neon-lime" />
          </div>

          <h2 className="text-3xl font-display font-bold text-white mb-2 leading-none">
            PROTOCOL<br/>COMPLETE
          </h2>
          
          <p className="text-zinc-400 text-sm mb-6">
            You successfully finished <span className="text-white font-bold">{challenge.title}</span>. 
            <br/>Focus integrity restored.
          </p>
          
          <div className="bg-zinc-900/50 rounded-xl p-4 border border-zinc-800 mb-6">
            <div className="flex justify-between items-center mb-2">
               <span className="text-xs text-zinc-500 uppercase">XP Gained</span>
               <span className="text-neon-lime font-bold">+{challenge.baseReward} XP</span>
            </div>
            <div className="flex justify-between items-center">
               <span className="text-xs text-zinc-500 uppercase">Duration</span>
               <span className="text-white font-bold">{challenge.selectedOption} Hours</span>
            </div>
          </div>

          <p className="text-xs text-zinc-500 uppercase tracking-widest mb-4">Share Achievement</p>
          
          <div className="grid grid-cols-4 gap-2 mb-6">
             <button onClick={() => handleShare('twitter')} className="h-12 rounded-xl bg-zinc-800 hover:bg-[#1DA1F2] hover:text-white flex items-center justify-center transition-colors text-zinc-400">
                <TwitterIcon className="w-5 h-5" />
             </button>
             <button onClick={() => handleShare('whatsapp')} className="h-12 rounded-xl bg-zinc-800 hover:bg-[#25D366] hover:text-white flex items-center justify-center transition-colors text-zinc-400">
                <MessageCircle className="w-5 h-5" />
             </button>
             <button onClick={() => handleShare('email')} className="h-12 rounded-xl bg-zinc-800 hover:bg-zinc-700 hover:text-white flex items-center justify-center transition-colors text-zinc-400">
                <Mail className="w-5 h-5" />
             </button>
             <button onClick={() => handleShare('copy')} className="h-12 rounded-xl bg-zinc-800 hover:bg-zinc-700 hover:text-white flex items-center justify-center transition-colors text-zinc-400">
                <Copy className="w-5 h-5" />
             </button>
          </div>

          <Button onClick={onClose} className="w-full bg-white text-black font-bold">
            Continue Journey
          </Button>

        </div>
      </div>
    </div>
  );
};
