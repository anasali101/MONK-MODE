
import React, { useState, useEffect, useRef } from 'react';
import { ActivityConfig, Profession, QuizQuestion } from '../types';
import { Button } from './Button';
import { playNatureAmbience, stopAudio } from '../services/audioService';
import { TRIVIA_QUESTIONS } from '../constants';
import { X, Play, RefreshCw, Zap, Wind, Check, Trash2, Brain, ChevronRight } from 'lucide-react';

interface ActivityModuleProps {
  config: ActivityConfig;
  onComplete: () => void;
  onExit: () => void;
  profession: Profession;
}

export const ActivityModule: React.FC<ActivityModuleProps> = ({ config, onComplete, onExit, profession }) => {
  const [step, setStep] = useState<'INTRO' | 'ACTIVE' | 'OUTRO'>('INTRO');
  const [timer, setTimer] = useState(config.durationSeconds);
  
  // Game State: Reaction
  const [reactionState, setReactionState] = useState<'WAITING' | 'READY' | 'CLICK' | 'TOO_SOON'>('WAITING');
  const [reactionTime, setReactionTime] = useState(0);
  const startTimeRef = useRef<number>(0);
  const reactionTimeoutRef = useRef<number>(0);

  // Game State: Trivia
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [shuffledQuestions, setShuffledQuestions] = useState<QuizQuestion[]>([]);

  // Game State: Shredder
  const [thought, setThought] = useState('');
  const [isShredding, setIsShredding] = useState(false);
  const [shredded, setShredded] = useState(false);

  // Initialize Trivia on Mount (Fresh shuffle every time component mounts)
  useEffect(() => {
    if (config.type === 'TRIVIA') {
      // Fisher-Yates shuffle then slice 10
      const shuffled = [...TRIVIA_QUESTIONS].sort(() => 0.5 - Math.random());
      setShuffledQuestions(shuffled.slice(0, 10));
    }
  }, [config.type]);

  // Start logic
  const handleStart = () => {
    setStep('ACTIVE');
    if (config.type === 'BREATHING') {
      playNatureAmbience();
    }
  };

  // Cleanup
  useEffect(() => {
    return () => {
      stopAudio();
      clearTimeout(reactionTimeoutRef.current);
    };
  }, []);

  // Timer for Breathing
  useEffect(() => {
    if (step === 'ACTIVE' && config.durationSeconds > 0 && config.type === 'BREATHING') {
      const interval = setInterval(() => {
        setTimer(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            stopAudio();
            setStep('OUTRO');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [step, config.type]);

  // Logic for Reaction Game
  const startReactionRound = () => {
    setReactionState('WAITING');
    const randomDelay = Math.random() * 3000 + 2000; // 2-5 seconds
    reactionTimeoutRef.current = window.setTimeout(() => {
      setReactionState('READY');
      startTimeRef.current = Date.now();
    }, randomDelay);
  };

  const handleReactionClick = () => {
    if (reactionState === 'WAITING') {
      clearTimeout(reactionTimeoutRef.current);
      setReactionState('TOO_SOON');
    } else if (reactionState === 'READY') {
      const time = Date.now() - startTimeRef.current;
      setReactionTime(time);
      setReactionState('CLICK');
    }
  };

  // Logic for Trivia
  const handleAnswer = (optionIndex: number) => {
    if (selectedOption !== null) return;
    setSelectedOption(optionIndex);
    const correct = optionIndex === shuffledQuestions[currentQIndex].correctIndex;
    if (correct) {
      setScore(s => s + 1);
    }
    setShowExplanation(true);
  };

  const nextQuestion = () => {
    if (currentQIndex < shuffledQuestions.length - 1) {
      setCurrentQIndex(prev => prev + 1);
      setSelectedOption(null);
      setShowExplanation(false);
    } else {
      setStep('OUTRO');
    }
  };

  // Logic for Shredder
  const handleShred = () => {
    if (!thought.trim()) return;
    setIsShredding(true);
    setTimeout(() => {
      setShredded(true);
      setTimeout(() => {
        setStep('OUTRO');
      }, 1500);
    }, 1000);
  };

  // --- Renders ---

  const renderIntro = () => (
    <div className="flex flex-col items-center justify-center h-full text-center space-y-8 animate-in fade-in zoom-in-95 p-6">
      <div className="w-24 h-24 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center shadow-[0_0_30px_rgba(255,255,255,0.1)]">
        {config.type === 'TRIVIA' && <Zap size={40} className="text-neon-lime" />}
        {config.type === 'BREATHING' && <Wind size={40} className="text-neon-blue" />}
        {config.type === 'REACTION' && <RefreshCw size={40} className="text-neon-purple" />}
        {config.type === 'SHREDDER' && <Trash2 size={40} className="text-rose-500" />}
      </div>
      <div>
        <h2 className="text-3xl font-display font-bold text-white mb-2">{config.title}</h2>
        <p className="text-zinc-400 max-w-xs mx-auto">{config.description}</p>
      </div>
      <Button onClick={handleStart} className="w-full bg-white text-black hover:bg-zinc-200 font-bold text-lg py-4">
        ENGAGE PROTOCOL
      </Button>
    </div>
  );

  const renderBreathing = () => (
    <div className="flex flex-col items-center justify-center h-full relative">
      <div className="absolute inset-0 bg-neon-blue/5 blur-[100px] rounded-full animate-pulse-fast"></div>
      
      {/* Breathing Circle */}
      <div className="relative z-10 w-64 h-64 border-2 border-neon-blue/30 rounded-full flex items-center justify-center transition-all duration-1000">
        <div className="w-full h-full bg-neon-blue/10 rounded-full animate-breathing flex items-center justify-center">
             <span className="text-4xl font-display font-bold text-white">{timer}</span>
        </div>
      </div>
      <div className="mt-12 text-center space-y-2">
        <p className="text-zinc-400 font-mono tracking-widest text-xs uppercase">Audio: Rain • Wind • Birds</p>
        <p className="text-white text-lg font-medium animate-pulse">Inhale... Hold... Exhale</p>
      </div>
    </div>
  );

  const renderReaction = () => (
    <div 
      className={`absolute inset-0 flex flex-col items-center justify-center cursor-pointer transition-colors duration-100
        ${reactionState === 'WAITING' ? 'bg-zinc-900' : 
          reactionState === 'READY' ? 'bg-neon-lime' : 
          reactionState === 'TOO_SOON' ? 'bg-rose-600' : 'bg-zinc-900'}`}
      onMouseDown={handleReactionClick}
      onTouchStart={handleReactionClick}
    >
      {reactionState === 'WAITING' && <p className="text-zinc-500 font-display text-2xl animate-pulse">Wait for Green...</p>}
      {reactionState === 'READY' && <p className="text-black font-black font-display text-4xl">TAP NOW!</p>}
      {reactionState === 'TOO_SOON' && (
        <div className="text-center">
          <p className="text-white font-bold text-2xl mb-4">Too Early!</p>
          <Button variant="secondary" onClick={(e) => { e.stopPropagation(); startReactionRound(); }}>Retry</Button>
        </div>
      )}
      {reactionState === 'CLICK' && (
        <div className="text-center bg-black/50 p-8 rounded-2xl backdrop-blur-xl border border-white/10">
          <p className="text-zinc-400 text-sm uppercase tracking-widest mb-2">Reaction Time</p>
          <p className="text-neon-lime font-display font-bold text-6xl mb-6">{reactionTime}ms</p>
          <div className="flex gap-4">
             <Button variant="secondary" onClick={(e) => { e.stopPropagation(); startReactionRound(); }}>Try Again</Button>
             <Button onClick={(e) => { e.stopPropagation(); setStep('OUTRO'); }}>Finish</Button>
          </div>
        </div>
      )}
      {reactionState === 'WAITING' && (
         <div className="absolute bottom-12 text-zinc-600 text-xs">Tap screen instantly when color changes</div>
      )}
    </div>
  );

  const renderTrivia = () => {
    if (shuffledQuestions.length === 0) return null;
    const q = shuffledQuestions[currentQIndex];
    
    return (
      <div className="flex flex-col h-full p-6 pt-12">
        <div className="flex justify-between items-center mb-6">
          <span className="text-xs font-mono text-zinc-500">Q{currentQIndex + 1}/{shuffledQuestions.length}</span>
          <span className="text-xs font-mono text-neon-lime">Score: {score}</span>
        </div>
        
        <div className="flex-grow">
          <h3 className="text-2xl font-display font-bold text-white mb-8 leading-tight">
            {q.question}
          </h3>
          
          <div className="space-y-3">
            {q.options.map((opt, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrect = idx === q.correctIndex;
              let btnClass = "w-full p-4 rounded-xl text-left border transition-all duration-200 ";
              
              if (selectedOption !== null) {
                if (isCorrect) btnClass += "bg-green-500/20 border-green-500 text-green-100";
                else if (isSelected) btnClass += "bg-red-500/20 border-red-500 text-red-100";
                else btnClass += "bg-zinc-900 border-zinc-800 text-zinc-500 opacity-50";
              } else {
                btnClass += "bg-zinc-900 border-zinc-800 text-zinc-200 hover:bg-zinc-800 hover:border-zinc-600";
              }

              return (
                <button 
                  key={idx}
                  onClick={() => handleAnswer(idx)}
                  disabled={selectedOption !== null}
                  className={btnClass}
                >
                  <div className="flex justify-between items-center">
                    <span>{opt}</span>
                    {selectedOption !== null && isCorrect && <Check size={18} className="text-green-500"/>}
                  </div>
                </button>
              );
            })}
          </div>

          {showExplanation && (
            <div className="mt-6 p-4 bg-zinc-900/50 border border-zinc-800 rounded-xl animate-in fade-in slide-in-from-bottom-2">
              <p className="text-sm text-zinc-300">
                <span className="font-bold text-white block mb-1">{selectedOption === q.correctIndex ? "Correct!" : "Missed it."}</span>
                {q.explanation}
              </p>
              <Button onClick={nextQuestion} className="w-full mt-4" size="sm">
                {currentQIndex < shuffledQuestions.length - 1 ? "Next Question" : "See Results"} <ChevronRight size={16} className="ml-1"/>
              </Button>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderShredder = () => (
    <div className="flex flex-col items-center justify-center h-full p-6">
      {!shredded ? (
        <>
          <div className="mb-8 text-center">
             <Brain size={48} className="text-rose-500 mx-auto mb-4" />
             <h2 className="text-2xl font-bold text-white mb-2">What is distracting you?</h2>
             <p className="text-zinc-500 text-sm">Type it out. Then destroy it.</p>
          </div>
          
          <div className={`w-full transition-all duration-1000 ${isShredding ? 'translate-y-24 opacity-0 scale-y-0' : ''}`}>
            <textarea
              value={thought}
              onChange={(e) => setThought(e.target.value)}
              placeholder="I am thinking about..."
              className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-4 text-white focus:outline-none focus:border-rose-500 h-32 resize-none mb-6"
            />
          </div>

          {isShredding && (
             <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-full h-1 bg-rose-500 animate-ping"></div>
             </div>
          )}

          <Button 
            onClick={handleShred} 
            disabled={!thought.trim() || isShredding}
            className="w-full bg-rose-600 hover:bg-rose-500 text-white"
          >
            {isShredding ? 'SHREDDING...' : 'DESTROY THOUGHT'}
          </Button>
        </>
      ) : (
        <div className="text-center animate-in zoom-in duration-500">
           <div className="w-20 h-20 bg-zinc-900 rounded-full flex items-center justify-center mx-auto mb-6 border border-zinc-800">
             <Check size={40} className="text-zinc-500" />
           </div>
           <h3 className="text-xl font-bold text-white">Thought Eliminated.</h3>
           <p className="text-zinc-500 mt-2">Your mind is clear.</p>
        </div>
      )}
    </div>
  );

  const renderOutro = () => (
    <div className="flex flex-col items-center justify-center h-full text-center space-y-6 animate-in fade-in slide-in-from-bottom-8 p-6">
      <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-4">
        <Check size={40} className="text-green-500" />
      </div>
      <h2 className="text-3xl font-display font-bold text-white">State Shifted</h2>
      <p className="text-zinc-400 max-w-xs">
        {config.type === 'TRIVIA' 
          ? `You scored ${score}/${shuffledQuestions.length}. Your brain is now active.` 
          : "Your pattern has been interrupted. Use this clarity."}
      </p>
      <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl w-full text-left">
        <p className="text-xs text-zinc-500 uppercase mb-2">Suggested Micro-Task</p>
        <p className="text-white font-medium">
          {profession === 'Software Engineer' ? 'Open your terminal. Type one command.' : 'Open a blank document. Write the title.'}
        </p>
      </div>
      <Button onClick={onComplete} className="w-full bg-white text-black font-bold">
        Back to Dashboard
      </Button>
    </div>
  );

  // Router
  if (step === 'INTRO') return renderIntro();
  if (step === 'OUTRO') return renderOutro();

  if (config.type === 'REACTION') return renderReaction(); // Full screen

  return (
    <div className="h-full relative bg-black">
      <button onClick={onExit} className="absolute top-4 right-4 p-2 bg-zinc-900 rounded-full text-zinc-500 hover:text-white z-50">
        <X size={20}/>
      </button>
      {config.type === 'BREATHING' && renderBreathing()}
      {config.type === 'TRIVIA' && renderTrivia()}
      {config.type === 'SHREDDER' && renderShredder()}
    </div>
  );
};
