
import React, { useState } from 'react';
import { Button } from './Button';
import { Lock, Unlock, AlertTriangle, ShieldAlert } from 'lucide-react';
import { UnlockJudgment } from '../types';
import { evaluateUnlockRequest } from '../services/geminiService';

interface UnlockModalProps {
  appName: string;
  isOpen: boolean;
  onClose: () => void;
  onUnlock: (minutes: number) => void;
}

export const UnlockModal: React.FC<UnlockModalProps> = ({ appName, isOpen, onClose, onUnlock }) => {
  const [reason, setReason] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<UnlockJudgment | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;

    setIsLoading(true);
    try {
      const judgment = await evaluateUnlockRequest(appName, reason);
      setResult(judgment);
      if (judgment.allowed) {
        setTimeout(() => {
          onUnlock(judgment.durationGranted || 15);
          onClose();
          setResult(null);
          setReason('');
        }, 2000);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setResult(null);
    setReason('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" onClick={handleClose}></div>
      
      <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
        <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-red-500 via-orange-500 to-red-500"></div>

        <div className="p-8 text-center">
          
          {!result ? (
            <>
              <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Lock className="w-8 h-8 text-red-500" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">The Vault is Locked</h2>
              <p className="text-zinc-400 mb-6">
                You have exceeded your limit for {appName}. Why do you need access? 
                <br/><span className="text-xs text-red-400 uppercase tracking-widest font-bold mt-2 block">AI Judge is Watching</span>
              </p>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Convince me it's important..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-red-500 transition-colors resize-none h-24"
                  autoFocus
                />
                <Button 
                  type="submit" 
                  isLoading={isLoading} 
                  disabled={!reason.trim()}
                  className="w-full bg-red-600 hover:bg-red-500 shadow-red-900/20"
                >
                  {isLoading ? 'ANALYZING EXCUSE...' : 'REQUEST UNLOCK'}
                </Button>
              </form>
            </>
          ) : (
            <div className={`transition-all duration-500 ${result.allowed ? 'scale-100' : 'shake'}`}>
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 ${result.allowed ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                {result.allowed ? <Unlock className="w-10 h-10 text-green-500" /> : <ShieldAlert className="w-10 h-10 text-red-500" />}
              </div>
              
              <h2 className={`text-3xl font-black mb-4 uppercase tracking-tighter ${result.allowed ? 'text-green-500' : 'text-red-500'}`}>
                {result.allowed ? 'ACCESS GRANTED' : 'ACCESS DENIED'}
              </h2>
              
              <div className="bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800">
                <p className="text-lg italic font-medium leading-relaxed">"{result.message}"</p>
              </div>

              {!result.allowed && (
                 <Button onClick={handleClose} variant="secondary" className="mt-6 w-full">
                   Back to Work
                 </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
