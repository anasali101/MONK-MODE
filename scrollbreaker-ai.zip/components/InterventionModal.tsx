
import React from 'react';
import { InterventionResponse } from '../types';
import { Button } from './Button';
import { X, CheckCircle2, Zap, BrainCircuit, ArrowRight } from 'lucide-react';

interface InterventionModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: InterventionResponse | null;
  onAccept: () => void;
}

export const InterventionModal: React.FC<InterventionModalProps> = ({ isOpen, onClose, data, onAccept }) => {
  if (!isOpen || !data) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/90 backdrop-blur-md transition-opacity animate-in fade-in duration-300" 
        onClick={onClose}
      ></div>
      
      {/* Modal Card */}
      <div className="relative w-full max-w-lg transform overflow-hidden rounded-3xl bg-zinc-900 border border-zinc-800 shadow-2xl transition-all animate-in zoom-in-95 duration-300">
        
        {/* Aesthetic Gradient Line */}
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-rose-500"></div>
        
        <div className="p-8 space-y-8">
          
          {/* Header */}
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-indigo-400">
                <BrainCircuit size={20} />
                <span className="text-xs font-bold uppercase tracking-widest">Analysis Complete</span>
              </div>
              <h2 className="text-3xl font-bold text-white">Pattern Detected</h2>
            </div>
            <button 
              onClick={onClose} 
              className="p-2 -mr-2 text-zinc-600 hover:text-zinc-300 transition-colors rounded-full hover:bg-zinc-800"
            >
              <X size={24} />
            </button>
          </div>

          {/* Reality Check Section */}
          <div className="bg-gradient-to-b from-rose-950/30 to-zinc-900 border border-rose-900/30 rounded-2xl p-6 relative overflow-hidden group">
             <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-rose-500/10 rounded-full blur-2xl group-hover:bg-rose-500/20 transition-all"></div>
             <h3 className="text-rose-500 text-xs font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
               <Zap size={14} /> The Hard Truth
             </h3>
             <p className="text-rose-100 text-lg md:text-xl font-medium leading-relaxed italic">
               "{data.realityCheck}"
             </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Mindfulness */}
            <div className="bg-zinc-800/50 rounded-2xl p-5 border border-zinc-700/50">
              <h4 className="text-zinc-400 text-xs font-bold uppercase tracking-wider mb-2">Reset System</h4>
              <p className="text-zinc-200 text-sm">{data.mindfulnessTrigger}</p>
            </div>
            
            {/* Micro Task */}
            <div className="bg-zinc-800/50 rounded-2xl p-5 border border-zinc-700/50">
              <h4 className="text-zinc-400 text-xs font-bold uppercase tracking-wider mb-2">Next Action</h4>
              <p className="text-zinc-200 text-sm font-semibold">{data.microTask}</p>
              <p className="text-indigo-400 text-xs mt-2 font-mono">Est: {data.estimatedTimeMinutes}m</p>
            </div>
          </div>

          {/* Action Footer */}
          <div className="flex gap-4 pt-2">
            <Button 
              variant="secondary" 
              onClick={onClose}
              className="flex-1 border-zinc-700 hover:bg-zinc-800"
            >
              Ignore & Scroll
            </Button>
            <Button 
              onClick={onAccept}
              className="flex-[2] bg-white text-black hover:bg-zinc-200 shadow-[0_0_20px_rgba(255,255,255,0.2)] border-0"
            >
              <span className="flex items-center justify-center gap-2">
                <CheckCircle2 size={18} />
                Accept Quest
              </span>
            </Button>
          </div>

        </div>
      </div>
    </div>
  );
};
