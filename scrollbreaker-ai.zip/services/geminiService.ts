
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { InterventionResponse, Mood, Profession, UnlockJudgment } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateIntervention = async (
  profession: Profession,
  mood: Mood
): Promise<InterventionResponse> => {
  if (!apiKey) {
    return {
      realityCheck: "You're scrolling because it's easier than failing. But you can't fail if you never start, which is a failure in itself.",
      microTask: "Write one single ugly line of code or text. Just one.",
      mindfulnessTrigger: "Unclench your jaw. Drop your shoulders. Inhale for 4 seconds.",
      estimatedTimeMinutes: 2
    };
  }

  const model = "gemini-2.5-flash";

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      realityCheck: {
        type: Type.STRING,
        description: "A witty, viral-worthy, slightly savage reality check. Max 2 sentences. Direct and provocative.",
      },
      microTask: {
        type: Type.STRING,
        description: "An incredibly specific, tiny first step related to the profession. 'Atomic habits' style.",
      },
      mindfulnessTrigger: {
        type: Type.STRING,
        description: "A quick physical reset action.",
      },
      estimatedTimeMinutes: {
        type: Type.INTEGER,
        description: "Time estimated for the micro task.",
      },
    },
    required: ["realityCheck", "microTask", "mindfulnessTrigger", "estimatedTimeMinutes"],
  };

  try {
    const response = await ai.models.generateContent({
      model,
      contents: `User Context: ${profession} feeling ${mood}. 
      Task: Generate a 'Pattern Interrupt' to stop them from doomscrolling.
      Tone: Viral productivity guru, slightly aggressive but helpful, witty, minimalist.
      
      Requirements:
      1. realityCheck: A punchy truth bomb about why they are avoiding work.
      2. microTask: The absolute smallest unit of progress for a ${profession} (e.g., 'Open VS Code', 'Write title').
      3. mindfulnessTrigger: A 10-second physical reset.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: 1.2,
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as InterventionResponse;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      realityCheck: "Comfort is the enemy of progress. You are choosing comfort right now.",
      microTask: "Open your primary tool and do nothing for 10 seconds.",
      mindfulnessTrigger: "Stand up and stretch your arms above your head.",
      estimatedTimeMinutes: 1
    };
  }
};

export const evaluateUnlockRequest = async (
  appName: string,
  reason: string
): Promise<UnlockJudgment> => {
  if (!apiKey) {
    // Mock logic for demo without API key
    const r = reason.toLowerCase();
    const isSerious = r.includes('work') || r.includes('urgent');
    const isSad = r.includes('depress') || r.includes('sad') || r.includes('cry') || r.includes('lonely');

    if (isSad) {
      return {
        allowed: true,
        message: "I hear you. If you're hurting, take a moment. But doomscrolling often makes it worse. 15 minutes, then try some fresh air.",
        durationGranted: 15
      };
    }

    return {
      allowed: isSerious,
      message: isSerious 
        ? "Fine. Make it count." 
        : `Really? '${reason}'? Weak. Go do something that actually matters.`,
      durationGranted: isSerious ? 15 : 0
    };
  }

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      allowed: { type: Type.BOOLEAN },
      message: { type: Type.STRING, description: "The response message to the user." },
      durationGranted: { type: Type.INTEGER, description: "0 if denied, 15 if allowed." }
    },
    required: ["allowed", "message", "durationGranted"]
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `
        Task: You are a strict Digital Gatekeeper for the app "${appName}". The user wants to unlock it.
        User's Reason: "${reason}"
        
        CRITICAL INSTRUCTIONS:
        1. **Depression Protocol**: If the user mentions depression, profound sadness, grief, or mental health struggles, BE EMPATHETIC. Allow the request (15m) but gently suggest that social media might not help. Do NOT roast them.
        2. **Strict Protocol**: For excuses like "bored", "tired", "just checking", "scrolling", "need a break" -> DENY IT. ROAST THEM HARD. Be funny but savage.
        3. **Work Protocol**: If reason is legitimate work/finance/emergency -> ALLOW IT (15 mins). Be stern.
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: 0.8
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text) as UnlockJudgment;
  } catch (e) {
    return {
      allowed: false,
      message: "My brain is fried, but you still shouldn't be scrolling. Denied.",
      durationGranted: 0
    };
  }
};
