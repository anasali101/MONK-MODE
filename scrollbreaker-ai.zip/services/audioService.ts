
// Advanced Web Audio API Engine
// Soundscape: Forest Cabin (River + Rain + Wind + Asian Koel)

let audioCtx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let nodes: AudioNode[] = [];
let birdTimeout: number | null = null;
let isPlaying = false;

// --- Utility: Noise Generators ---

const createBuffer = (type: 'pink' | 'brown', duration: number) => {
  if (!audioCtx) return null;
  const bufferSize = audioCtx.sampleRate * duration;
  const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const data = buffer.getChannelData(0);

  if (type === 'pink') {
    // Pink Noise (Rain/Wind high freq)
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      data[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
      data[i] *= 0.11; 
      b6 = white * 0.115926;
    }
  } else {
    // Brown Noise (River/Rumble)
    let lastOut = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      data[i] = (lastOut + (0.02 * white)) / 1.02;
      lastOut = data[i];
      data[i] *= 3.5; // Compensate for gain loss
    }
  }
  return buffer;
};

// --- Layers ---

const createRiverLayer = () => {
  if (!audioCtx || !masterGain) return;
  const buffer = createBuffer('brown', 5);
  if (!buffer) return;

  const source = audioCtx.createBufferSource();
  source.buffer = buffer;
  source.loop = true;

  // Lowpass filter to make it deep and distant
  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = 300; // Increased clarity slightly

  const gain = audioCtx.createGain();
  gain.gain.value = 0.6; // BOOSTED LEVEL

  source.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);
  source.start();
  nodes.push(source, filter, gain);
};

const createRainOnLeavesLayer = () => {
  if (!audioCtx || !masterGain) return;
  const buffer = createBuffer('pink', 5);
  if (!buffer) return;

  const source = audioCtx.createBufferSource();
  source.buffer = buffer;
  source.loop = true;

  const filter = audioCtx.createBiquadFilter();
  filter.type = 'highpass'; // Thin sound for leaves
  filter.frequency.value = 600;

  const gain = audioCtx.createGain();
  gain.gain.value = 0.3; // BOOSTED LEVEL

  source.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);
  source.start();
  nodes.push(source, filter, gain);
};

const createWindLayer = () => {
  if (!audioCtx || !masterGain) return;
  const buffer = createBuffer('pink', 10);
  if (!buffer) return;

  const source = audioCtx.createBufferSource();
  source.buffer = buffer;
  source.loop = true;

  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = 400;

  // Modulate the filter to simulate gusting wind
  const lfo = audioCtx.createOscillator();
  lfo.type = 'sine';
  lfo.frequency.value = 0.15; // Slow gusts

  const lfoGain = audioCtx.createGain();
  lfoGain.gain.value = 300; // Modulation depth

  lfo.connect(lfoGain);
  lfoGain.connect(filter.frequency);

  const gain = audioCtx.createGain();
  gain.gain.value = 0.4; // BOOSTED LEVEL

  source.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);
  
  source.start();
  lfo.start();
  nodes.push(source, filter, lfo, lfoGain, gain);
};

// --- Asian Koel Synthesis ---
// The call is a distinct "Koo-Ooo" rising in pitch.
const triggerAsianKoel = () => {
  if (!audioCtx || !masterGain || !isPlaying) return;

  const t = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = 'sine';
  
  // Pitch Glide: Starts at ~700Hz, rises to ~1300Hz (Clearer)
  osc.frequency.setValueAtTime(700, t);
  osc.frequency.exponentialRampToValueAtTime(1300, t + 0.4);
  osc.frequency.setValueAtTime(1300, t + 0.4); // Hold briefly
  
  // Volume Envelope: Fade in, hold, fade out
  gain.gain.setValueAtTime(0, t);
  gain.gain.linearRampToValueAtTime(0.25, t + 0.1); // BOOSTED LEVEL
  gain.gain.setValueAtTime(0.25, t + 0.3);
  gain.gain.linearRampToValueAtTime(0, t + 0.6);

  osc.connect(gain);
  gain.connect(masterGain);

  osc.start(t);
  osc.stop(t + 0.7);

  // Often they call twice in quick succession
  if (Math.random() > 0.4) {
     const t2 = t + 0.8;
     const osc2 = audioCtx.createOscillator();
     const gain2 = audioCtx.createGain();
     
     osc2.type = 'sine';
     osc2.frequency.setValueAtTime(750, t2);
     osc2.frequency.exponentialRampToValueAtTime(1400, t2 + 0.4);
     
     gain2.gain.setValueAtTime(0, t2);
     gain2.gain.linearRampToValueAtTime(0.25, t2 + 0.1);
     gain2.gain.linearRampToValueAtTime(0, t2 + 0.6);
     
     osc2.connect(gain2);
     gain2.connect(masterGain);
     osc2.start(t2);
     osc2.stop(t2 + 0.7);
  }
};

const scheduleBirds = () => {
  if (!isPlaying) return;
  // Koels call less frequently, spaced out
  const delay = 3000 + Math.random() * 7000; 
  birdTimeout = window.setTimeout(() => {
    if (isPlaying) {
      triggerAsianKoel();
      scheduleBirds();
    }
  }, delay);
};

// --- Main Control ---

export const playNatureAmbience = async () => {
  // 1. Cleanup existing
  stopAudio();

  // 2. Initialize Context
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }

  // 3. FORCE RESUME (Critical for mobile/autoplay)
  try {
    if (audioCtx.state === 'suspended') {
      await audioCtx.resume();
    }
  } catch (e) {
    console.error("Audio Context Resume Failed:", e);
  }

  isPlaying = true;
  masterGain = audioCtx.createGain();
  masterGain.gain.value = 0.001; // Start barely audible
  masterGain.connect(audioCtx.destination);
  nodes.push(masterGain);

  // 4. Create Soundscape
  createRiverLayer();      // The base
  createRainOnLeavesLayer();       // The texture
  createWindLayer();       // The movement

  // 5. Fast Fade In (0.5s) to ensure user hears it immediately
  masterGain.gain.exponentialRampToValueAtTime(1.0, audioCtx.currentTime + 0.5);

  // 6. Start Wildlife
  scheduleBirds();
};

export const stopAudio = () => {
  isPlaying = false;
  if (birdTimeout) clearTimeout(birdTimeout);

  if (masterGain && audioCtx) {
    // Quick fade out
    try {
      masterGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.1);
    } catch(e) {}
  }

  // Hard disconnect after fade
  setTimeout(() => {
    nodes.forEach(node => {
      try {
        node.disconnect();
        if ((node as AudioBufferSourceNode).stop) (node as AudioBufferSourceNode).stop();
        if ((node as OscillatorNode).stop) (node as OscillatorNode).stop();
      } catch (e) {
        // ignore errors on already stopped nodes
      }
    });
    nodes = [];
  }, 200);
};
